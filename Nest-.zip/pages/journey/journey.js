// pages/journey/journey.js
var app=getApp()
Page({
// 页面的初始数据
    data: {
        winWidth:0,
        winHeight:0,
        // tab切换
        currentTab: 0,
    },
    // 实现页面跳转
    onhomepage:function(options){
        wx:wx.navigateTo({
          url: '../index/index'
        })
    },
    ontravels:function(options){
        wx:wx.navigateTo({
          url: '../notes/notes'
        })
    },
    onme:function(options){
        wx:wx.navigateTo({
          url: '../user/user'
        })
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad:function() {
        var that=this;
        // 获取系统信息
        wx.getSystemInfo({
            success:function(res){
                that.setData({
                    winWidth:res.windowWidth,
                    winHeight:res.windowHeight
                });
            }
        });
    },
    bindChange:function(e){
        var that=this;
        that.setData({currentTab:e.detail.current});
    },
    // 点击头部tab切换
    swichNav:function (e) {
        var that=this;
        if(this.data.currentTab===e.target.dataset.current){
            return false;
        }else{
            that.setData({
                currentTab:e.target.dataset.current
            })
        }
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})